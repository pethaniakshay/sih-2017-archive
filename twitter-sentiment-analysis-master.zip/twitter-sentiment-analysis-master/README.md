# Twitter Sentiment Analysis
Conducts sentiment analysis on tweets by hashtag, and then visualizes the mood around that hashtag through a web app.
