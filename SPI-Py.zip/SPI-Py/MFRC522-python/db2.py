#!/usr/bin/python

import MySQLdb

# Open database connection
db = MySQLdb.connect("localhost","root","root","tt" )

# prepare a cursor object using cursor() method
cursor = db.cursor()

# Prepare SQL query to INSERT a record into the database.
sql = "SELECT * FROM test \
       WHERE rfid = '%s'" % (19220817876)
try:
   # Execute the SQL command
   cursor.execute(sql)
   # Fetch all the rows in a list of lists.
   results = cursor.fetchall()
   for row in results:
      sr = row[0]
      rfid = row[1]
      balance = row[2]
      
      # Now print fetched result
      print "sr=%s,rfid=%s,balance=%d" % \
             (sr, rfid, balance)
except:
   print "Error: unable to fecth data"

# disconnect from server
db.close()